package com.matrixco.browser

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.net.HttpURLConnection
import java.net.URL

/** Local SQLite database: filters, history, per-site settings, block stats. */
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "matrixco.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE filters(domain TEXT PRIMARY KEY)")
        d.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT, title TEXT, ts INTEGER)")
        d.execSQL("CREATE TABLE site_settings(host TEXT PRIMARY KEY, skipwait INTEGER DEFAULT 0, adblock INTEGER DEFAULT 1)")
        d.execSQL("CREATE TABLE stats(host TEXT PRIMARY KEY, blocked INTEGER DEFAULT 0)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun loadFilters(): HashSet<String> {
        val s = HashSet<String>()
        val c = readableDatabase.rawQuery("SELECT domain FROM filters", null)
        while (c.moveToNext()) s.add(c.getString(0))
        c.close(); return s
    }
    fun replaceFilters(list: Collection<String>) {
        val d = writableDatabase
        d.beginTransaction()
        try {
            d.execSQL("DELETE FROM filters")
            val st = d.compileStatement("INSERT OR IGNORE INTO filters(domain) VALUES(?)")
            for (x in list) { st.clearBindings(); st.bindString(1, x); st.executeInsert() }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun flag(host: String, col: String, def: Boolean): Boolean {
        val c = readableDatabase.rawQuery("SELECT $col FROM site_settings WHERE host=?", arrayOf(host))
        val r = if (c.moveToFirst()) c.getInt(0) == 1 else def
        c.close(); return r
    }
    fun setFlag(host: String, col: String, v: Boolean) {
        val d = writableDatabase
        d.execSQL("INSERT OR IGNORE INTO site_settings(host) VALUES(?)", arrayOf<Any>(host))
        d.execSQL("UPDATE site_settings SET $col=? WHERE host=?", arrayOf<Any>(if (v) 1 else 0, host))
    }
    fun addHistory(url: String, title: String) {
        writableDatabase.execSQL("INSERT INTO history(url,title,ts) VALUES(?,?,?)",
            arrayOf<Any>(url, title, System.currentTimeMillis()))
    }
    fun recent(n: Int): List<Pair<String, String>> {
        val c = readableDatabase.rawQuery("SELECT url,title FROM history ORDER BY id DESC LIMIT $n", null)
        val l = ArrayList<Pair<String, String>>()
        while (c.moveToNext()) l.add(Pair(c.getString(0), c.getString(1) ?: ""))
        c.close(); return l
    }
    fun addBlocked(host: String, n: Int) {
        if (n <= 0 || host.isEmpty()) return
        val d = writableDatabase
        d.execSQL("INSERT OR IGNORE INTO stats(host) VALUES(?)", arrayOf<Any>(host))
        d.execSQL("UPDATE stats SET blocked=blocked+? WHERE host=?", arrayOf<Any>(n, host))
    }
    fun totalBlocked(): Long {
        val c = readableDatabase.rawQuery("SELECT IFNULL(SUM(blocked),0) FROM stats", null)
        val r = if (c.moveToFirst()) c.getLong(0) else 0L
        c.close(); return r
    }
}

/** Domain-based ad/tracker blocker with auto-updating filter lists. */
class AdBlocker(private val ctx: Context, private val db: Db) {
    @Volatile private var domains: HashSet<String> = HashSet()

    companion object {
        val LISTS = listOf(
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
        )
        val BUILTIN = listOf(
            "doubleclick.net", "googlesyndication.com", "adservice.google.com", "adnxs.com",
            "taboola.com", "outbrain.com", "popads.net", "propellerads.com", "adsterra.com",
            "googleadservices.com", "moatads.com", "scorecardresearch.com", "criteo.com"
        )
        val WHITELIST = listOf("playconqueronline.com")

        const val COSMETIC_JS = "(function(){if(window.__mxCss)return;window.__mxCss=1;var s=document.createElement('style');" +
            "s.textContent='ins.adsbygoogle,[id*=\"google_ads\"],[class*=\"adsbygoogle\"],[id^=\"ad-\"],[class*=\"ad-banner\"]," +
            "[id*=\"banner-ad\"],[class*=\"advert\"],iframe[src*=\"doubleclick\"],iframe[src*=\"/ads/\"],.sponsored," +
            "[aria-label=\"advertisement\" i]{display:none!important}';(document.head||document.documentElement).appendChild(s);})();"

        const val SKIP_JS = "(function(){if(window.__mxSkip)return;window.__mxSkip=1;var st=window.setTimeout,si=window.setInterval;" +
            "window.setTimeout=function(f,d){var a=[].slice.call(arguments,2);if(d>=1000)d=Math.max(30,d/20);return st.apply(window,[f,d].concat(a));};" +
            "window.setInterval=function(f,d){var a=[].slice.call(arguments,2);if(d>=1000)d=Math.max(30,d/20);return si.apply(window,[f,d].concat(a));};})();"
    }

    init { domains = db.loadFilters().also { it.addAll(BUILTIN) } }

    fun isBlocked(host: String?): Boolean {
        var h = host ?: return false
        if (WHITELIST.any { h == it || h.endsWith(".$it") }) return false
        val d = domains
        while (true) {
            if (d.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    fun updateIfStale() = update(false, null)

    fun update(force: Boolean, cb: ((Int) -> Unit)?) {
        val p = ctx.getSharedPreferences("matrixco", Context.MODE_PRIVATE)
        if (!force && System.currentTimeMillis() - p.getLong("filters_ts", 0) < 86400000L) return
        Thread {
            val set = HashSet<String>()
            for (u in LISTS) try { set.addAll(fetch(u)) } catch (e: Exception) { }
            if (set.size > 500) {
                db.replaceFilters(set)
                set.addAll(BUILTIN); domains = set
                p.edit().putLong("filters_ts", System.currentTimeMillis()).apply()
            }
            cb?.invoke(domains.size)
        }.start()
    }

    private fun fetch(u: String): List<String> {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        val out = ArrayList<String>()
        c.inputStream.bufferedReader().useLines { ls ->
            for (l in ls) {
                val t = l.trim()
                if (t.isEmpty() || t.startsWith("#")) continue
                val parts = t.split(Regex("\\s+"))
                val d = (if (parts.size >= 2) parts[1] else parts[0]).lowercase()
                if (d.contains('.') && !d.contains('/') && !d.contains(':') && d != "0.0.0.0") out.add(d)
            }
        }
        c.disconnect(); return out
    }
}

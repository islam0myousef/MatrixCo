package com.matrixco.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private val RED = Color.parseColor("#E11D2E")
    private val BG = Color.parseColor("#0B0B0F")
    private val HOME = "https://browser.playconqueronline.com"
    private val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "adservice.google.com", "adnxs.com",
        "taboola.com", "outbrain.com", "popads.net", "propellerads.com", "adsterra.com"
    )

    private val prefs by lazy { getSharedPreferences("matrixco", Context.MODE_PRIVATE) }
    private val tabs = mutableListOf<WebView>()
    private var cur = 0
    private var barsHidden = false

    private lateinit var frame: FrameLayout
    private lateinit var urlBox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var tabsBtn: TextView

    private fun on(k: String) = prefs.getBoolean(k, true)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, a: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 20f
        gravity = Gravity.CENTER; setPadding(dp(14), dp(12), dp(14), dp(12))
        setOnClickListener { a() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        urlBox = EditText(this).apply {
            setSingleLine(); hint = "Search or type web address"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 14f
            setBackgroundColor(Color.parseColor("#1A1A22"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
        }
        topBar.addView(urlBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(btn("➜") { go(urlBox.text.toString()) })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(RED)
        }
        frame = FrameLayout(this)

        bottomBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#12121A")) }
        tabsBtn = btn("1") { showTabs() }
        val items = listOf(
            btn("◀") { tabs[cur].let { if (it.canGoBack()) it.goBack() } },
            btn("▶") { tabs[cur].let { if (it.canGoForward()) it.goForward() } },
            btn("⌂") { tabs[cur].loadUrl(HOME) },
            tabsBtn,
            btn("⋮") { showMenu() }
        )
        items.forEach { bottomBar.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }

        root.addView(topBar)
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar)
        setContentView(root)

        newTab(intent?.data?.toString() ?: HOME)
        applyGameMode()
    }

    // ---------- Tabs ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun newWebView(): WebView {
        val w = WebView(this)
        w.setBackgroundColor(BG)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = on("popups")
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = if (on("desktop")) DESKTOP_UA else WebSettings.getDefaultUserAgent(this@MainActivity)
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val h = r.url.host ?: return null
                if (on("adblock") && adHosts.any { h.endsWith(it) })
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                return null
            }
            override fun onPageStarted(v: WebView, u: String, f: android.graphics.Bitmap?) {
                if (v === tabs.getOrNull(cur)) urlBox.setText(u)
            }
            override fun onPageFinished(v: WebView, u: String) { autoLogin(v, u) }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === tabs.getOrNull(cur)) progress.progress = if (p >= 100) 0 else p
            }
        }
        return w
    }

    private fun newTab(url: String) {
        val w = newWebView(); tabs.add(w); show(tabs.size - 1); w.loadUrl(url)
    }

    private fun show(i: Int) {
        cur = i; frame.removeAllViews(); frame.addView(tabs[i])
        urlBox.setText(tabs[i].url ?: ""); tabsBtn.text = tabs.size.toString()
    }

    private fun closeTab() {
        if (tabs.size == 1) { tabs[0].loadUrl(HOME); return }
        val w = tabs.removeAt(cur); w.destroy(); show(minOf(cur, tabs.size - 1))
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, w -> "${i + 1}. ${w.title ?: w.url ?: "New Tab"}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Tabs").setItems(names) { _, i -> show(i) }
            .setNeutralButton("New Tab") { _, _ -> newTab(HOME) }.show()
    }

    private fun go(q: String) {
        val t = q.trim(); if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        tabs[cur].loadUrl(url)
    }

    // ---------- Menu ----------
    private fun showMenu() {
        val items = arrayOf(
            "New Tab", "Close Tab", "Game Settings", "Save Account for this site",
            "Show/Hide Bars", "Clear Cache", "Exit"
        )
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> newTab(HOME)
                1 -> closeTab()
                2 -> gameSettings()
                3 -> saveAccount()
                4 -> toggleBars()
                5 -> { tabs[cur].clearCache(true); Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show() }
                6 -> finishAffinity()
            }
        }.show()
    }

    private fun gameSettings() {
        val keys = arrayOf("fullscreen", "landscape", "adblock", "desktop", "keepon", "popups")
        val names = arrayOf("Fullscreen", "Landscape Lock", "Block Ads", "Desktop Site (User Agent)", "Keep Screen On", "Allow Popups")
        val checked = BooleanArray(keys.size) { on(keys[it]) }
        AlertDialog.Builder(this).setTitle("Game Mode")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Apply") { _, _ ->
                keys.forEachIndexed { i, k -> prefs.edit().putBoolean(k, checked[i]).apply() }
                tabs.forEach { w ->
                    w.settings.userAgentString =
                        if (on("desktop")) DESKTOP_UA else WebSettings.getDefaultUserAgent(this)
                    w.settings.javaScriptCanOpenWindowsAutomatically = on("popups")
                }
                applyGameMode(); tabs[cur].reload()
            }.show()
    }

    private fun applyGameMode() {
        requestedOrientation = if (on("landscape")) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (on("keepon")) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersive()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        window.decorView.systemUiVisibility = if (on("fullscreen"))
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        else View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun toggleBars() {
        barsHidden = !barsHidden
        val v = if (barsHidden) View.GONE else View.VISIBLE
        topBar.visibility = v; bottomBar.visibility = v; progress.visibility = v
        if (barsHidden) Toast.makeText(this, "Menu: press Back to show bars", Toast.LENGTH_SHORT).show()
    }

    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) applyImmersive() }

    // ---------- Accounts / Auto login ----------
    private fun hostOf(u: String?) = Uri.parse(u ?: "").host ?: ""

    private fun saveAccount() {
        val host = hostOf(tabs[cur].url); if (host.isEmpty()) return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val u = EditText(this).apply { hint = "Username"; setSingleLine() }
        val p = EditText(this).apply {
            hint = "Password"; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(u); box.addView(p)
        AlertDialog.Builder(this).setTitle("Account: $host").setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("acc:$host", u.text.toString() + "\n" + p.text.toString()).apply()
            }
            .setNegativeButton("Delete") { _, _ -> prefs.edit().remove("acc:$host").apply() }
            .show()
    }

    private fun autoLogin(v: WebView, url: String) {
        val saved = prefs.getString("acc:" + hostOf(url), null) ?: return
        val parts = saved.split("\n", limit = 2); if (parts.size < 2) return
        val js = "(function(u,p){var all=document.querySelectorAll('input'),pw=null,us=null;" +
                "all.forEach(function(e){if(e.type=='password'&&!pw)pw=e;});if(!pw)return;" +
                "all.forEach(function(e){if(!us&&(e.type=='text'||e.type=='email')&&!e.disabled)us=e;});" +
                "function set(el,x){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,x);" +
                "el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}" +
                "if(us)set(us,u);set(pw,p);})(" + JSONObject.quote(parts[0]) + "," + JSONObject.quote(parts[1]) + ");"
        v.evaluateJavascript(js, null)
    }

    // ---------- Lifecycle ----------
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            barsHidden -> toggleBars()
            tabs[cur].canGoBack() -> tabs[cur].goBack()
            tabs.size > 1 -> closeTab()
            else -> super.onBackPressed()
        }
    }
    override fun onPause() { super.onPause(); tabs.forEach { it.onPause() } }
    override fun onResume() { super.onResume(); tabs.forEach { it.onResume() } }
}

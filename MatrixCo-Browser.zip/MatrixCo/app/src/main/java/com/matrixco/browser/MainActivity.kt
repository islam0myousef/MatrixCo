package com.matrixco.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private var RED = Color.parseColor("#E11D2E")
    private val THEMES = listOf(
        "Dark Red" to Color.parseColor("#E11D2E"), "Gold" to Color.parseColor("#F5B301"),
        "Blue" to Color.parseColor("#2D8CFF"), "Purple" to Color.parseColor("#8E44FF"),
        "Green" to Color.parseColor("#22C55E"), "Classic" to Color.parseColor("#BBBBBB")
    )
    private val BG = Color.parseColor("#0B0B0F")
    private val HOME = "https://matrixco.home/"
    private val GAME = "https://browser.playconqueronline.com"
    private val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "adservice.google.com", "adnxs.com",
        "taboola.com", "outbrain.com", "popads.net", "propellerads.com", "adsterra.com"
    )

    private val prefs by lazy { getSharedPreferences("matrixco", Context.MODE_PRIVATE) }
    private val tabs = mutableListOf<WebView>()
    private var cur = 0
    private var barsHidden = false
    private lateinit var db: Db
    private lateinit var ab: AdBlocker
    private lateinit var blockedTv: TextView
    private val pageBlocked = java.util.concurrent.atomic.AtomicInteger(0)

    private lateinit var frame: FrameLayout
    private lateinit var urlBox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var tabsBtn: TextView

    private fun on(k: String) = prefs.getBoolean(k, true)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, a: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 20f
        gravity = Gravity.CENTER; setPadding(dp(14), dp(12), dp(14), dp(12))
        setOnClickListener { a() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        db = Db(this); ab = AdBlocker(this, db); ab.updateIfStale()
        RED = THEMES[prefs.getInt("theme", 0).coerceIn(0, THEMES.size - 1)].second
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        urlBox = EditText(this).apply {
            setSingleLine(); hint = "Search or type web address"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 14f
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#14141C")); cornerRadius = dp(22).toFloat(); setStroke(dp(1), RED)
            }
            setPadding(dp(12), dp(8), dp(12), dp(8))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
        }
        topBar.addView(urlBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        blockedTv = TextView(this).apply { text = "🛡0"; setTextColor(RED); textSize = 13f; setPadding(dp(8), 0, dp(4), 0) }
        topBar.addView(blockedTv)
        topBar.addView(btn("➜") { go(urlBox.text.toString()) })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(RED)
        }
        frame = FrameLayout(this)

        bottomBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#12121A")) }
        tabsBtn = btn("1") { showTabs() }.apply { setTextColor(RED); setTypeface(null, android.graphics.Typeface.BOLD) }
        val items = listOf(
            btn("◀") { tabs[cur].let { if (it.canGoBack()) it.goBack() } },
            btn("▶") { tabs[cur].let { if (it.canGoForward()) it.goForward() } },
            btn("⌂") { loadHome(tabs[cur]) },
            tabsBtn,
            btn("⋮") { showMenu() }
        )
        items.forEach { bottomBar.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }

        root.addView(topBar)
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar)
        setContentView(root)
        window.statusBarColor = BG; window.navigationBarColor = BG
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(BG)
            addView(TextView(context).apply {
                text = "MaTriX Co"; textSize = 38f; setTextColor(RED)
                setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
            })
            addView(TextView(context).apply {
                text = "GAME BROWSER"; textSize = 12f; setTextColor(Color.GRAY)
                gravity = Gravity.CENTER; letterSpacing = 0.3f
            })
            addView(ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
                isIndeterminate = true; indeterminateTintList = ColorStateList.valueOf(RED)
            }, LinearLayout.LayoutParams(dp(160), dp(4)).apply { topMargin = dp(24) })
        }
        addContentView(splash, android.view.ViewGroup.LayoutParams(-1, -1))
        splash.postDelayed({
            splash.animate().alpha(0f).setDuration(400).withEndAction {
                (splash.parent as? android.view.ViewGroup)?.removeView(splash)
            }.start()
        }, 1200)

        newTab(intent?.data?.toString() ?: HOME)
        applyGameMode()
    }

    // ---------- Home / theme / orientation ----------
    private fun shownUrl(u: String?) = if (u == null || u.contains("matrixco.home")) "" else u

    private fun updateOrientation(url: String?) {
        val game = (url ?: "").contains("playconqueronline")
        requestedOrientation = if (game && on("landscape")) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    private fun loadHome(w: WebView) {
        w.loadDataWithBaseURL(HOME, homeHtml(), "text/html", "utf-8", null)
    }

    private fun pickTheme() {
        AlertDialog.Builder(this).setTitle("Theme")
            .setItems(THEMES.map { it.first }.toTypedArray()) { _, i ->
                prefs.edit().putInt("theme", i).apply(); toast("Restart the app to apply the theme")
            }.show()
    }

    private fun homeHtml(): String {
        val a = "#%06X".format(0xFFFFFF and RED)
        val tiles = listOf(
            "Conquer Online" to GAME, "YouTube" to "https://m.youtube.com", "Facebook" to "https://m.facebook.com",
            "Google" to "https://www.google.com", "Discord" to "https://discord.com/app"
        )
        val sb = StringBuilder()
        for ((n, u) in tiles) sb.append("<a class=t href='$u'><b>${n.take(1)}</b><span>$n</span></a>")
        return "<html><head><meta name=viewport content='width=device-width,initial-scale=1'><style>" +
            "body{margin:0;background:radial-gradient(circle at 50% 0,#3a0a10,#0B0B0F 60%);color:#fff;font-family:sans-serif;text-align:center;padding:24px 16px}" +
            "h1{margin:28px 0 2px;font-size:34px}h1 i{color:$a;font-style:normal}p{margin:0 0 22px;color:#aaa;letter-spacing:4px;font-size:11px}" +
            "form{margin:0 auto 26px;max-width:480px}input{width:100%;box-sizing:border-box;padding:14px 18px;border-radius:26px;border:1px solid $a;background:#14141c;color:#fff;font-size:16px;outline:0}" +
            ".g{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;max-width:480px;margin:auto}" +
            ".t{background:#14141c;border:1px solid #2a2a35;border-radius:16px;padding:16px 6px;color:#fff;text-decoration:none}" +
            ".t b{display:block;width:46px;height:46px;line-height:46px;margin:0 auto 8px;border-radius:50%;background:$a;font-size:22px}.t span{font-size:12px}" +
            "</style></head><body><h1>MaTriX <i>Co</i></h1><p>GAME BROWSER</p>" +
            "<form action='https://www.google.com/search'><input name=q placeholder='Search or type web address'></form>" +
            "<div class=g>" + sb + "</div></body></html>"
    }

    // ---------- Tabs ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun newWebView(): WebView {
        val w = WebView(this)
        w.setBackgroundColor(BG)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = on("popups")
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = if (on("desktop")) DESKTOP_UA else WebSettings.getDefaultUserAgent(this@MainActivity)
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val h = r.url.host ?: return null
                if (!r.isForMainFrame && on("adblock") && ab.isBlocked(h)) {
                    val n = pageBlocked.incrementAndGet()
                    runOnUiThread { blockedTv.text = "🛡$n" }
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val sch = r.url.scheme
                if (sch != "http" && sch != "https") return true
                return on("adblock") && !r.hasGesture() && ab.isBlocked(r.url.host)
            }
            override fun onPageStarted(v: WebView, u: String, f: android.graphics.Bitmap?) {
                if (v === tabs.getOrNull(cur)) { urlBox.setText(shownUrl(u)); updateOrientation(u); pageBlocked.set(0); blockedTv.text = "🛡0" }
                injectScripts(v, u)
            }
            override fun onPageFinished(v: WebView, u: String) {
                autoLogin(v, u); injectScripts(v, u)
                if (u.startsWith("http") && !u.contains("matrixco.home")) db.addHistory(u, v.title ?: "")
                db.addBlocked(hostOf(u), pageBlocked.get())
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, dialog: Boolean, gesture: Boolean, msg: android.os.Message): Boolean {
                if (!gesture && on("adblock")) return false
                val nw = newWebView(); tabs.add(nw); show(tabs.size - 1)
                (msg.obj as WebView.WebViewTransport).webView = nw
                msg.sendToTarget(); return true
            }
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === tabs.getOrNull(cur)) progress.progress = if (p >= 100) 0 else p
                if (p in 5..60) injectScripts(v, v.url ?: "")
            }
        }
        return w
    }

    private fun newTab(url: String) {
        val w = newWebView(); tabs.add(w); show(tabs.size - 1)
        if (url == HOME) loadHome(w) else w.loadUrl(url)
    }

    private fun show(i: Int) {
        cur = i; frame.removeAllViews(); frame.addView(tabs[i])
        urlBox.setText(shownUrl(tabs[i].url)); tabsBtn.text = tabs.size.toString(); updateOrientation(tabs[i].url)
    }

    private fun closeTab() {
        if (tabs.size == 1) { loadHome(tabs[0]); return }
        val w = tabs.removeAt(cur); w.destroy(); show(minOf(cur, tabs.size - 1))
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, w -> "${i + 1}. ${w.title ?: w.url ?: "New Tab"}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Tabs").setItems(names) { _, i -> show(i) }
            .setNeutralButton("New Tab") { _, _ -> newTab(HOME) }.show()
    }

    private fun go(q: String) {
        val t = q.trim(); if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        tabs[cur].loadUrl(url)
    }

    // ---------- Menu ----------
    private fun injectScripts(v: WebView, url: String) {
        val host = hostOf(url)
        if (host.isEmpty()) return
        if (on("adblock") && db.flag(host, "adblock", true)) v.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
        if (db.flag(host, "skipwait", false)) v.evaluateJavascript(AdBlocker.SKIP_JS, null)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun showHistory() {
        val rows = db.recent(50)
        val names = rows.map { if (it.second.isEmpty()) it.first else it.second }.toTypedArray()
        AlertDialog.Builder(this).setTitle("History")
            .setItems(names) { _, i -> tabs[cur].loadUrl(rows[i].first) }.show()
    }

    private fun showMenu() {
        val host = hostOf(tabs[cur].url)
        val sw = db.flag(host, "skipwait", false)
        val items = arrayOf(
            "New Tab", "Close Tab", "Game Settings", "Save Account for this site",
            "Show/Hide Bars", "Clear Cache",
            "Skip Wait on this site: " + (if (sw) "ON" else "OFF"),
            "Update ad filter lists", "History", "Blocked ads total", "Theme", "Exit"
        )
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> newTab(HOME)
                1 -> closeTab()
                2 -> gameSettings()
                3 -> saveAccount()
                4 -> toggleBars()
                5 -> { tabs[cur].clearCache(true); toast("Cache cleared") }
                6 -> { if (host.isNotEmpty()) { db.setFlag(host, "skipwait", !sw); tabs[cur].reload() } }
                7 -> { toast("Updating filters..."); ab.update(true) { n -> runOnUiThread { toast("Filters ready: $n domains") } } }
                8 -> showHistory()
                9 -> toast("Blocked so far: " + db.totalBlocked())
                10 -> pickTheme()
                11 -> finishAffinity()
            }
        }.show()
    }

    private fun gameSettings() {
        val keys = arrayOf("fullscreen", "landscape", "adblock", "desktop", "keepon", "popups")
        val names = arrayOf("Fullscreen", "Landscape Lock", "Block Ads", "Desktop Site (User Agent)", "Keep Screen On", "Allow Popups")
        val checked = BooleanArray(keys.size) { on(keys[it]) }
        AlertDialog.Builder(this).setTitle("Game Mode")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Apply") { _, _ ->
                keys.forEachIndexed { i, k -> prefs.edit().putBoolean(k, checked[i]).apply() }
                tabs.forEach { w ->
                    w.settings.userAgentString =
                        if (on("desktop")) DESKTOP_UA else WebSettings.getDefaultUserAgent(this)
                    w.settings.javaScriptCanOpenWindowsAutomatically = on("popups")
                }
                applyGameMode(); tabs[cur].reload()
            }.show()
    }

    private fun applyGameMode() {
        updateOrientation(tabs.getOrNull(cur)?.url)
        if (on("keepon")) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersive()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        window.decorView.systemUiVisibility = if (on("fullscreen"))
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        else View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun toggleBars() {
        barsHidden = !barsHidden
        val v = if (barsHidden) View.GONE else View.VISIBLE
        topBar.visibility = v; bottomBar.visibility = v; progress.visibility = v
        if (barsHidden) Toast.makeText(this, "Menu: press Back to show bars", Toast.LENGTH_SHORT).show()
    }

    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) applyImmersive() }

    // ---------- Accounts / Auto login ----------
    private fun hostOf(u: String?) = Uri.parse(u ?: "").host ?: ""

    private fun saveAccount() {
        val host = hostOf(tabs[cur].url); if (host.isEmpty()) return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val u = EditText(this).apply { hint = "Username"; setSingleLine() }
        val p = EditText(this).apply {
            hint = "Password"; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(u); box.addView(p)
        AlertDialog.Builder(this).setTitle("Account: $host").setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("acc:$host", u.text.toString() + "\n" + p.text.toString()).apply()
            }
            .setNegativeButton("Delete") { _, _ -> prefs.edit().remove("acc:$host").apply() }
            .show()
    }

    private fun autoLogin(v: WebView, url: String) {
        val saved = prefs.getString("acc:" + hostOf(url), null) ?: return
        val parts = saved.split("\n", limit = 2); if (parts.size < 2) return
        val js = "(function(u,p){var all=document.querySelectorAll('input'),pw=null,us=null;" +
                "all.forEach(function(e){if(e.type=='password'&&!pw)pw=e;});if(!pw)return;" +
                "all.forEach(function(e){if(!us&&(e.type=='text'||e.type=='email')&&!e.disabled)us=e;});" +
                "function set(el,x){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,x);" +
                "el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}" +
                "if(us)set(us,u);set(pw,p);})(" + JSONObject.quote(parts[0]) + "," + JSONObject.quote(parts[1]) + ");"
        v.evaluateJavascript(js, null)
    }

    // ---------- Lifecycle ----------
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            barsHidden -> toggleBars()
            tabs[cur].canGoBack() -> tabs[cur].goBack()
            tabs.size > 1 -> closeTab()
            else -> super.onBackPressed()
        }
    }
    override fun onPause() { super.onPause(); tabs.forEach { it.onPause() } }
    override fun onResume() { super.onResume(); tabs.forEach { it.onResume() } }
}

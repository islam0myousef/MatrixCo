MaTriX Co - Gaming Browser (Android, Kotlin, no external libraries)
1) Open Android Studio > File > Open > select the MatrixCo folder
2) Wait for Gradle sync (needs internet the first time)
3) Build > Build APK(s)  (or Run on your phone)
APK path: app/build/outputs/apk/debug/app-debug.apk
